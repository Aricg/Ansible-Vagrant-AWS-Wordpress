#!/bin/bash
. fingerconfig

num="$("$shuf" -i 0-3 -n 1)"

logos=()
while read -r logo; do
	logos+=("$logo")
done < <(find "$dir" -type f -name "*.txt")

cat "${logos["$num"]}" #2> /dev/null 
